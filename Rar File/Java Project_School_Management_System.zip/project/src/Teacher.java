public class Teacher {
	public String tname;
	public int tid;
	public String tmail;
	public String tphone;
	public String taddress;
	public String tjoindate;

}

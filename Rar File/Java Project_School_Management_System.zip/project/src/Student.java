
public class Student {
	
	public String name;
	public int id;
	public String classname;
	public String fname;
	public String fno;
	public String mname;
	public String mno;
	public String address;
	
}

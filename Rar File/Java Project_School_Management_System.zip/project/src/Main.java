
public class Main{
	public static void main(String[] args) {
		new loginPage();
		//TeacherRegistration h=new TeacherRegistration();
		//h.setVisible(true);
		//new createUser();
		//studentForm s=new studentForm();
		//s.setVisible(true);
		
		//new adminHome();
	}
}
